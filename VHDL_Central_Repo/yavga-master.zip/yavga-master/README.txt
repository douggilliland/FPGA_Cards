########################################################
#### This file is part of the yaVGA project         ####
#### http://www.opencores.org/?do=project&who=yavga ####
########################################################

This core is a semi semigraphic vga controller.

It generate the signal to drive a vga monitor with an 800x600 resolution
and 72Hz vertical refresh rate

It display monochromatic chars on the screen from a ram memory

It can display a color "waveform" (a sort of function) from another ram memory

It can display a color grid and "cross cursor"

vhdl
  this directory contains the hdl and constraint files

charmaps
  this directory contains some scripts useful to change the char maps

LICENSE.txt
  the license

README.txt
  this file

xilinx
  this directory contain xilinx ISE generated files
