This is the source code for "the empty shell" program from the book
"Assembly Cookbook for the Apple II/IIe" by Don Lancaster, ported to
the CC65 assembler.
