This is the source code for the Cassette Interface for the Apple 1.
It is intended to be assembled with CC65 (See http://www.cc65.org).
