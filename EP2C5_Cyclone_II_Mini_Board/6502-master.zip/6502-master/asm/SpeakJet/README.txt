The file speakjet.bas is an Apple 1 BASIC program that demonstrates
use of the SpeakJet chip on a Briel Computers Multi I/O Board. The
program came from the Multi I/O Board Setup and Users manual.
