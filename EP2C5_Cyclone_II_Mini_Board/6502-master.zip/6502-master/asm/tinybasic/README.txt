This is a port of Tiny BASIC to the Replica 1.

Changes needed:

- modifications to assemble with CC65
- input and output routines modified for Replica 1
- memory map changes to run out of RAM by default
- don't print LF after CR

See:

http://en.wikipedia.org/wiki/Tiny_BASIC
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/index.htm
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/TinyBasic.asm
