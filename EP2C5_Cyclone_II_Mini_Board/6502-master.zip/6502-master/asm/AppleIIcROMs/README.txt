This is source code for the Apple //c computer's ROM. It can generate
all four versions of the ROM for the Apple //c (but not the Apple //c
Plus). It started with a disassembly of the binaries and over time I
am polishing it and adding the original source code comments from the
Apple manuals (where available).

Some info on the ROM versions can be found here:
http://apple2online.com/web_documents/apple_iic_rom_versions.pdf
