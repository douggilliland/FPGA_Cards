This is source for the KIM-1 computer ROMs.

It can be assembled with the CC65 assembler (see http://www.cc65.org).

It also requires the S record utility found at
http://srecord.sourceforge.net

I have confirmed that the generated binary matches the original KIM-1
ROM binary.
