This is TinyBasic for the KIM-1.

See:

http://en.wikipedia.org/wiki/Tiny_BASIC
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/index.htm
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/TinyBasic.asm
