These are the source code, documentation, and paper tape download
files for the programs from "The First Book of KIM" by Jim
Butterfield, Stan Ockers, and Eric Rehnke.

This book is out of print but is available from sources such as eBay
and scanned versions can be found on the Internet.

The source code is intended to be assembled using the CC65 tools
(http://www.cc65.org/).

It also uses the SRecord tool from http://srecord.sourceforge.net/
to produce paper tape files in MOS Technology format.

Almost all of the programs have been tested on a KIM-1 computer, but
there may have been errors introduced when entering them. I would
appreciate any feedback on errors or other issues.

I have included any corrections listed in later versions of the book,
where I was aware of them.

Jeff Tranter <tranter@pobox.com>
