BANDIT
JIM BUTTERFIELD

Start the program at 0200 and on the right, you'll see the $25
that KIM has given you to play with. The funny symbols on the
left are your "wheels" - hit any key and see them spin.

Every time you spin the wheels by hitting a key it costs you $1.
When the wheels stop, you might have a winning combination,
in which case you'll see money being added to your total
on the right. Most of the time, you'll get nothing ...
but that's the luck of the game.

The biggest jackpot is $15: that's three bars across the
display. Other combinations pay off, too; you'll soon learn
to recognize the "cherry" symbol, which pays $2 every time
it shows in the left hand window.

There's no house percentage, so you can go a long time on
your beginning $25. The most you can make is $99; and if
you run out of money, too bad: KIM doesn't give credit.

You'll notice that the listing for BANDIT looks a little
different from others in this book. That's because it
is the output of a resident assembler operating in
an expanded KIM system. See the section on expansion
for a further discussion of assemblers.

You might like to change the payouts so that there is
a "house percentage". That way, visitors will eventually
run out of money if they play long enough. This has
two possible advantages: it will teach them the evils
of gambling, and they won't hog your KIM all day playing
this game.
