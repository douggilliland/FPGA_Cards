KIM NIM
BY JIM BUTTERFIELD

Here's a jumbo NIM that's good for all skill levels.
Why?  Because KIM matches wits with you - literally.
Play a duffer's game and KIM will make lots of errors,
too.  Start winning a few - and KIM will move up to
the master player level.

Hit GO and several digits on the KIM display will light.
Each lit digit represents a pile of objects you can
pick from.  Decide which pile you want, and enter
its identity:  A for the left-hand pile through to
F for the right-hand pile.  The pile you have selected
will start to flash on and off.  Now enter the number
of items you want to take from that pile.

KIM will take its turn the same way - you'll see
the pile selected begin to flash, and then some
items will be taken away.  After the computer moves,
it's your turn again.

The winner is the player who takes the last object.
When this happens, KIM will identify the winner.
A new game can be started at any time by hitting GO.
