TIMER
By Joel Swank

Description -
   TIMER turns KIM into a digital stopwatch showing up to
99 minutes and 59.99 seconds. It is designed to be accurate
to 50 microseconds per second. The interval timer is used
to count 9984 cycles and the instructions between the time
out and the reset of the timer make up the other 16 cycles
in .01 seconds. The keyboard is used to control the routine
as follows: Stop (0), Go (1), Return to KIM (4) , Reset (2).
