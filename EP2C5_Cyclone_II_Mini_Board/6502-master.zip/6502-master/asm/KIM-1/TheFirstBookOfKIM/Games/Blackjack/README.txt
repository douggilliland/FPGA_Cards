BLACKJACK
BY JIM BUTTERFIELD

Description:

     KIM uses a  'real' deck of cards in this game.
So when you've seen four aces going by, you know
that there will be no more - until the next shuffle.

BLACKJACK starts at address 0200.  You'll see the
cards being shuffled - the word SHUFFL appears on the
display - and then KIM will ask how much you want to bet.

You'll start with an initial amount of $20.  Your balance
is always shown to the right of the BET? question, so
on the first hand, you'll see BET? 20 on the display.

You may bet from $1 to $9, which is the house limit.
The instant you hit key 1 to 9 to signal your bet,
KIM will deal.  Of course, you can't bet more money
than you have ... and KIM ignores freeloaders who try
to bet a zero amount.

After the deal, you'll see both your cards on the left
of the display, and one of KIM's cards on the right.
(KIM's other card is a 'hole  card, and you won't see
it until it's KIM's turn to play).  Aces are shown
as letter A, face cards and tens as letter F, and
other cards as their value, two to nine.  As always,
Aces count value 1 or 11 and face cards count 10.

You can call for a third card by hitting the 3 button ..
then the fourth card with the 4 button, and so on.
If your total goes over 21 points, KIM will ungrammatically
say BUSTED, and you'll lose.  If you get five cards
without exceeding 21 points, you'll win automatically.
If you don't want any more cards, hit key 0.  KIM will
report your point total, and then will show and play
its own hand.  KIM, too, might go BUSTED or win on
a five-card hand.  Otherwise, the most points wins.

From time to time, KIM will advise SHUFFL when the
cards start to run low.

Remember that you have a good chance to beat KIM at
this game.  Keep track of the cards that have been
dealt (especially aces and face cards), and you're
likely to be a winner!
