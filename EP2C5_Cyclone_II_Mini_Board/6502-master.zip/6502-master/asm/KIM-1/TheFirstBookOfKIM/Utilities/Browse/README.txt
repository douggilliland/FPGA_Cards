BROWSE
Jim Butterfield

Load BROWSE anywhere in memory - it's fully relocatable -
start it up, and presto!  It doesn't seem to do anything.

BROWSE is a mini-Monitor that performs most of the functions
of the regular KIM monitor; but you'll find it handy for entering
and proof-reading programs.  Most of the keys work the same as
usual; but PC,  +, and DA are slightly different.

When you hit + you go to the next address as usual .. but then
you keep on going!  Great for proofreading a program you've
just entered.  It lets you browse through memory.

Hit PC and the program steps backwards, so you can look at
a value you've just passed.  All other keys instantly freeze
the browsing process; you can hit AD or DA to stop on a given
address, or just enter a new address if you wish.

Key DA operates a little differently from the regular KIM
function.  To enter data, first set up the address before
the one you want to change.  As you enter the data, BROWSE
will automatically step forward to the next address - and
then the next one, and so on.  You never need to hit the +
key during entry; and the display will show the last value
you have entered.
