These are programs for the KIM-1 microcomputer. They may also run on
compatible computers like the Briel Computers Micro-KIM and the
various KIM-1 emulators that are available.
