This is a port of the Lemonade Stand program to the Apple Replica 1.

The original program was written by Bob Jamison of the Minnesota
educational computing consortium and modified for the Apple ][ by
Charlie Kellner.

The code was obtained from http://www.codenautics.com/lemonade/

It needs Applesoft Lite (not the Apple Integer BASIC built into
the Replica 1). See http://cowgod.org/replica1/applesoft/

I extracted the original source code from the PDF file and removed
anything to do with POKES, graphics, etc. that was not supported on
the Replica 1.

Jeff Tranter <tranter@pobox.com>
4 Apr 2012
