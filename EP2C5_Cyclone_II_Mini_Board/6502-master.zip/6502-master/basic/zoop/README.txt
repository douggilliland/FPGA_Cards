This program enhances BASIC to make it a much more user-friendly and
pleasant environment to work in -- or maybe not :-) Seriously, just
run it and try it. Looking at the source code first will spoil the
fun.

Provided is a Woz Mon binary as well as source code. Either can be
loaded but the binary may be easier to load.

It was inspired by a program called ZOOP in the book "101 BASIC
Computer Games" by David H. Ahl.
