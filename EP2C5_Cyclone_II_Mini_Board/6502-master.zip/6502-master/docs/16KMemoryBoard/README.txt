This is a design for a 16K RAM/EEPROM card for the Replica 1.
