Skye's Castle is a sequel to The Abandoned Farmhouse Adventure, a text
adventure game in the spirit of similar games that ran on 8-bit
microcomputers of the 1970s and 80s or the more ambitious Colossal
Cave adventure that originally only ran on mainframes and
minicomputers.

The plot and game should be self-explanatory. Figuring it out is the
point of the game.

It was written to run on the Apple II although it is in portable C and
should run on any system with a C compiler (I did most of the
development and testing on a Linux system).

The source is included and under an Apache license so you can modify
and adapt the code if you wish. Much of the code is data-driven and
could be used to implement an entirely different adventure just by
changing the map, strings, and some of the logic that handles special
actions.

The castle is based on a real castle. I leave it up to you to figure
out which one - there should be enough clues in the game.

I also have granddaughter named Skye who was 3 years old at the time I
wrote this.

Jeff Tranter <tranter@pobox.com>
http://jefftranter.blogspot.ca/
