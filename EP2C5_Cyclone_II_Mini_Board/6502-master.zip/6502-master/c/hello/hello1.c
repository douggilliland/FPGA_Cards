#include <stdio.h>

int main (void)
{
    printf("\nHELLO, WORLD!\n");
    return 0;
}
